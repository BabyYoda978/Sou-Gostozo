"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.memberLeftVoiceChannel = exports.pointOpenedResponse = exports.pointClosedResponse = exports.noVoiceChannel = exports.pointWasCreated = exports.noPermissionCommand = exports.totalHours = exports.pointWasClosed = exports.notHaveOpenPoint = exports.pointWasOpened = exports.alreadyHaveOpenPoint = void 0;
const discord_js_1 = require("discord.js");
const formatMilliseconds_1 = require("./formatMilliseconds");
const moment_1 = __importDefault(require("moment"));
moment_1.default.locale('pt-br');

let startTime; // Variável para armazenar a hora de início do ponto

const alreadyHaveOpenPoint = (guild) => new discord_js_1.EmbedBuilder()
    .setColor("2f3136")
    .setDescription(`<a:nao:1124780044175282186> Você já está com um ponto aberto. Feche-o primeiro para que possa abrir outro novamente.`);
exports.alreadyHaveOpenPoint = alreadyHaveOpenPoint;

const pointWasOpened = (member) => {
    startTime = moment_1.default(); // Armazena a hora de início quando o ponto é aberto
    const startTimeFormatted = startTime.format('HH:mm'); // Obtém a hora de início formatada como HH:mm

    return new discord_js_1.EmbedBuilder()
        .setColor("#FF0000")
        .setDescription(`**🔴  INÍCIO:** *${startTimeFormatted}*\n**🔴  TERMINOU:** *~~EM PTR~~*`);
};
exports.pointWasOpened = pointWasOpened;

const notHaveOpenPoint = (guild) => new discord_js_1.EmbedBuilder()
    .setColor("2f3136")
    .setDescription(`<a:nao:1124780044175282186> Você não está com um ponto aberto. Abra um primeiro para que possa fechar.`);
exports.notHaveOpenPoint = notHaveOpenPoint;

const pointWasClosed = (guild, member, timeWorked) => {
    const currentTime = moment_1.default().format('HH:mm'); // Obtém a hora atual formatada como HH:mm

    return new discord_js_1.EmbedBuilder()
        .setColor(0x6ce460)
        .setDescription(`**🟢  INÍCIO:** *${startTime.format('HH:mm')}*\n**🟢  TERMINOU:** *${currentTime}*\n**🟢  HORAS FEITAS:** *${(0, formatMilliseconds_1.formatMilliseconds)(timeWorked)}*`);
};
exports.pointWasClosed = pointWasClosed;

const totalHours = (guild, timeWorked) => new discord_js_1.EmbedBuilder()
    .setColor("2f3136")
    .setDescription(`⏰・**Horais totais feitas:** ${(0, formatMilliseconds_1.formatMilliseconds)(timeWorked)}.`);
exports.totalHours = totalHours;

const noPermissionCommand = (guild) => new discord_js_1.EmbedBuilder()
    .setColor("2f3136")
    .setDescription(`<a:nao:1124780044175282186> Você não tem permissões suficientes para usar esse comando.`);
exports.noPermissionCommand = noPermissionCommand;

const pointWasCreated = (guild) => new discord_js_1.EmbedBuilder()
    .setColor("2f3136")
    .setDescription(`<a:sim:1124780055562829944> A mensagem principal do ponto foi criada com sucesso.`);
exports.pointWasCreated = pointWasCreated;

const noVoiceChannel = (guild) => new discord_js_1.EmbedBuilder()
    .setColor("2f3136")
    .setDescription(`<a:nao:1124780044175282186> Para utilizar esse botão você precisa estar em um canal de voz do bate-ponto`);
exports.noVoiceChannel = noVoiceChannel;

const pointOpenedResponse = (message) => new discord_js_1.EmbedBuilder()
    .setColor("2f3136")
    .setDescription(`<a:sim:1124780055562829944> Seu ponto foi aberto com sucesso nesse canal: <#1112469567323766864>.`);
exports.pointOpenedResponse = pointOpenedResponse;

const pointClosedResponse = (message) => new discord_js_1.EmbedBuilder()
    .setColor("2f3136")
    .setDescription(`<a:sim:1124780055562829944> Seu ponto foi fechado com sucesso, veja suas horas aqui: <#1112469567323766864>.`);
exports.pointClosedResponse = pointClosedResponse;

const memberLeftVoiceChannel = (guild, member, timeWorked) => {
    const currentTime = moment_1.default(); // Obtém a hora atual como hora de término
    const currentTimeFormatted = currentTime.format('HH:mm'); // Obtém a hora atual formatada
  
    return new discord_js_1.EmbedBuilder()
        .setColor("#ffff00")
        .setDescription(`**🟡  INÍCIO:** *${startTime.format('HH:mm')}*\n**🟡  TERMINOU:** *${currentTimeFormatted}*\n**🟡  HORAS FEITAS:** *${(0, formatMilliseconds_1.formatMilliseconds)(timeWorked)}*\n**<:1094036512024305777:1117185882793984122> AVISO:** ***Esse ponto foi fechado por conta que o mesmo saiu da call!***`);
};
exports.memberLeftVoiceChannel = memberLeftVoiceChannel;
//# sourceMappingURL=responseEmbeds.js.map