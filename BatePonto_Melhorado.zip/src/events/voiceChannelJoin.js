"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const discord_js_1 = require("discord.js");
const configs = require("../config.json");
const UsersRepository_1 = require("../repositories/UsersRepository");
const responseEmbeds_1 = require("../structures/responseEmbeds");

function voiceChannelJoin(client) {
  const workingUsers = new Set();

  client.on('voiceStateUpdate', async (oldState, newState) => {
    const member = newState.member;
    const oldChannel = oldState.channel;
    const newChannel = newState.channel;

    // Check if member joined or left a voice channel
    if (newChannel || oldChannel) {
      await handleMemberVoiceUpdate(member, oldChannel, newChannel, workingUsers);
    }
  });

  async function handleMemberVoiceUpdate(member, oldChannel, newChannel, workingUsers) {
    const user = await UsersRepository_1.usersRepository.get(member.id);

    // Check if member joined a voice channel
    if (newChannel && configs.pointVoiceChannelsId.includes(newChannel.id) && (!oldChannel || !configs.pointVoiceChannelsId.includes(oldChannel.id))) {
      await handleMemberJoined(member, newChannel, workingUsers);
    }

    // Check if member left a voice channel
    if (oldChannel && configs.pointVoiceChannelsId.includes(oldChannel.id) && (!newChannel || !configs.pointVoiceChannelsId.includes(newChannel.id))) {
      await handleMemberLeft(member, oldChannel, newChannel, workingUsers);
    }
  }

  async function handleMemberJoined(member, channel, workingUsers) {
    const user = await UsersRepository_1.usersRepository.get(member.id);
    if (user && !user.startedWorkAt && !workingUsers.has(member.id)) {
      // Verificar se o usuário estava em uma call configurada anteriormente
      if (channel && configs.pointVoiceChannelsId.includes(channel.id)) {
        return; // Ignorar o início automático do ponto de trabalho
      }

      const currentTime = new Date();

      UsersRepository_1.usersRepository.update(member.id, (user) => {
        user.startedWorkAt = currentTime;
      });

      const logChannel = channel.guild.channels.cache.get(configs.pointLogChannel);
      if (logChannel && logChannel instanceof discord_js_1.TextChannel) {
        const mainEmbed = responseEmbeds_1.pointWasOpened(member, currentTime);
        logChannel.send({
          content: member.toString(),
          embeds: [mainEmbed]
        });
      }

      workingUsers.add(member.id);
    }
  }  

  async function handleMemberLeft(member, oldChannel, newChannel, workingUsers) {
    const user = await UsersRepository_1.usersRepository.get(member.id);
    if (user && user.startedWorkAt) {
      const startTime = new Date(user.startedWorkAt);
      const endTime = new Date();

      const timeWorked = endTime.getTime() - startTime.getTime();
      UsersRepository_1.usersRepository.update(member.id, (user) => {
        user.startedWorkAt = null;
        user.pointHours += timeWorked;
      });

      const logChannel = oldChannel.guild.channels.cache.get(configs.pointLogChannel);
      if (logChannel && logChannel instanceof discord_js_1.TextChannel) {
        const mainEmbed = responseEmbeds_1.memberLeftVoiceChannel(oldChannel.guild, member, timeWorked);
        logChannel.send({
          content: member.toString(),
          embeds: [mainEmbed]
        });
      }
    }

    // Check if member joined a voice channel before leaving
    if (newChannel && configs.pointVoiceChannelsId.includes(newChannel.id)) {
      workingUsers.delete(member.id);
    }
  }
}

exports.default = voiceChannelJoin;